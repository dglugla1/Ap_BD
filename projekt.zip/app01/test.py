#------------------------------------------------------------------------------
# hiperłącze (link) + wywietlenie zawartosci dwóch tabel
#------------------------------------------------------------------------------

from flask import Flask,request,url_for,redirect
from flask import render_template
import os
import sqlite3
from flask import url_for
import numpy as np


app = Flask(__name__)


work_path='C:\\examplesPython\\venv\\app01'
curr_path=os.chdir(work_path)

con = sqlite3.connect('baza1.db')

con.row_factory = sqlite3.Row

cur = con.cursor()

#ADRES
def adresPokaz():
    cur.execute(
        """
        SELECT * FROM adres
        """)
    row = cur.fetchone()
    names = row.keys()
    naglowek=[]
    for row in names:
        naglowek.append(row)
    naglowek=tuple(i for i in naglowek)
    cur.execute(
        """
        SELECT * FROM adres
        """)
    osoby = cur.fetchall()
    rekordy=[]
    rekordy.append(naglowek)
    for row in osoby:
        rekordy.append(tuple(row))
    import numpy as np
    data_array=np.array(rekordy)
    return data_array
data_array=adresPokaz()
def adres_insert(ulica,numer,numer_mieszkania,kod,miasto):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('INSERT INTO adres VALUES(NULL,?,?,?,?,?)',(ulica,numer,numer_mieszkania,kod,miasto))
    con.commit()
    return redirect(url_for("tabela1"))
def adres_del(id):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute("DELETE FROM adres WHERE idadres= ?",(id,))
    con.commit()
    return redirect(url_for("tabela1"))
def adres_update(idadres,ulica,numer,numer_mieszkania,kod,miasto):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('UPDATE adres SET ulica=? where idadres=?',(ulica,idadres))
    cur.execute('UPDATE adres SET numer_mieszkania=? where idadres=?',(numer_mieszkania,idadres))
    cur.execute('UPDATE adres SET numer=? where idadres=?',(numer,idadres))
    cur.execute('UPDATE adres SET kod=? where idadres=?',(kod,idadres))
    cur.execute('UPDATE adres SET miasto=? where idadres=?',(miasto,idadres))
    con.commit()
    return redirect(url_for("tabela1"))


#TWORCA
def tworcaPokaz():
    cur.execute(
        """
        SELECT * FROM tworca
        """)
    row = cur.fetchone()
    names = row.keys()
    naglowek=[]
    for row in names:
        naglowek.append(row)
    naglowek=tuple(i for i in naglowek)
    cur.execute(
        """
        SELECT * FROM tworca
        """)
    osoby = cur.fetchall()
    rekordy=[]
    rekordy.append(naglowek)
    for row in osoby:
        rekordy.append(tuple(row))
    import numpy as np
    data_array2=np.array(rekordy)
    return data_array2
data_array2=tworcaPokaz()
def tworca_insert(idadres,imie,nazwisko,pesel,nr_telefonu,email):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('INSERT INTO tworca VALUES(NULL,?,?,?,?,?,?)',(idadres,imie,nazwisko,pesel,nr_telefonu,email))
    con.commit()
    return redirect(url_for("tabela2"))
def tworca_del(id):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute("DELETE FROM tworca WHERE idtworca= ?",(id,))
    con.commit()
    return redirect(url_for("tabela2"))
def tworca_update(idtworca,imie,nazwisko,pesel,nr_telefonu,email):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('UPDATE tworca SET imie=? where idtworca=?',(imie,idtworca))
    cur.execute('UPDATE tworca SET nazwisko=? where idtworca=?',(nazwisko,idtworca))
    cur.execute('UPDATE tworca SET pesel=? where idtworca=?',(pesel,idtworca))
    cur.execute('UPDATE tworca SET nr_telefonu=? where idtworca=?',(nr_telefonu,idtworca))
    cur.execute('UPDATE tworca SET email=? where idtworca=?',(email,idtworca))
    con.commit()
    return redirect(url_for("tabela2"))


#KLIENT
def klientPokaz():
    cur.execute(
        """
        SELECT * FROM klient
        """)
    row = cur.fetchone()
    names = row.keys()
    naglowek=[]
    for row in names:
        naglowek.append(row)
    naglowek=tuple(i for i in naglowek)
    cur.execute(
        """
        SELECT * FROM klient
        """)
    osoby = cur.fetchall()
    rekordy=[]
    rekordy.append(naglowek)
    for row in osoby:
        rekordy.append(tuple(row))
    import numpy as np
    data_array3=np.array(rekordy)
    return data_array3
data_array3=klientPokaz()
def klient_insert(idadres,imie,nazwisko,pesel,nr_telefonu,email):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('INSERT INTO tworca VALUES(NULL,?,?,?,?,?,?)',(idadres,imie,nazwisko,pesel,nr_telefonu,email))
    con.commit()
    return redirect(url_for("tabela3"))
def klient_del(id):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute("DELETE FROM klient WHERE idklient= ?",(id,))
    con.commit()
    return redirect(url_for("tabela3"))
def klient_update(idklient,imie,nazwisko,pesel,nr_telefonu,email):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('UPDATE klient SET imie=? where idklient=?',(imie,idklient))
    cur.execute('UPDATE klient SET nazwisko=? where idklient=?',(nazwisko,idklient))
    cur.execute('UPDATE klient SET pesel=? where idklienta=?',(pesel,idklient))
    cur.execute('UPDATE klient SET nr_telefonu=? where idklient=?',(nr_telefonu,idklient))
    cur.execute('UPDATE klient SET email=? where idklient=?',(email,idklient))
    con.commit()
    return redirect(url_for("tabela3"))


#ZNIZKA
def znizkaPokaz():
    cur.execute(
        """
        SELECT * FROM znizka
        """)
    row = cur.fetchone()
    names = row.keys()
    naglowek=[]
    for row in names:
        naglowek.append(row)
    naglowek=tuple(i for i in naglowek)
    cur.execute(
        """
        SELECT * FROM znizka
        """)
    osoby = cur.fetchall()
    rekordy=[]
    rekordy.append(naglowek)
    for row in osoby:
        rekordy.append(tuple(row))
    import numpy as np
    data_array4=np.array(rekordy)
    return data_array4
data_array4=znizkaPokaz()
def znizka_insert(kod_rabatowy):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('INSERT INTO znizka VALUES(NULL,?)',(kod_rabatowy))
    con.commit()
    return redirect(url_for("tabela4"))
def znizka_del(id):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute("DELETE FROM znizka WHERE idznizka= ?",(id,))
    con.commit()
    return redirect(url_for("tabela4"))
def znizka_update(idznizka,kod_rabatowy):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('UPDATE znizka SET kod_rabatowy=? where idznizka=?',(kod_rabatowy,idznizka))
    con.commit()
    return redirect(url_for("tabela4"))


#KATEGORIA
def kategoriaPokaz():
    cur.execute(
        """
        SELECT * FROM kategoria
        """)
    row = cur.fetchone()
    names = row.keys()
    naglowek=[]
    for row in names:
        naglowek.append(row)
    naglowek=tuple(i for i in naglowek)
    cur.execute(
        """
        SELECT * FROM kategoria
        """)
    osoby = cur.fetchall()
    rekordy=[]
    rekordy.append(naglowek)
    for row in osoby:
        rekordy.append(tuple(row))
    import numpy as np
    data_array5=np.array(rekordy)
    return data_array5
data_array5=kategoriaPokaz()
def kategoria_insert(nazwa):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('INSERT INTO kategoria VALUES(NULL,?)',(nazwa))
    con.commit()
    return redirect(url_for("tabela5"))
def kategoria_del(id):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute("DELETE FROM kategoria WHERE idkategoria= ?",(id,))
    con.commit()
    return redirect(url_for("tabela5"))
def kategoria_update(idkategoria,nazwa):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('UPDATE kategoria SET nazwa=? where idkategoria=?',(nazwa,idkategoria))
    con.commit()
    return redirect(url_for("tabela5"))


#OBRAZ
def obrazPokaz():
    cur.execute(
        """
        SELECT * FROM obraz
        """)
    row = cur.fetchone()
    names = row.keys()
    naglowek=[]
    for row in names:
        naglowek.append(row)
    naglowek=tuple(i for i in naglowek)
    cur.execute(
        """
        SELECT * FROM obraz
        """)
    osoby = cur.fetchall()
    rekordy=[]
    rekordy.append(naglowek)
    for row in osoby:
        rekordy.append(tuple(row))
    import numpy as np
    data_array6=np.array(rekordy)
    return data_array6
data_array6=obrazPokaz()
def obraz_insert(idtworca,idkategoria,tytul,cena):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('INSERT INTO obraz VALUES(NULL,?,?,?,?)',(idtworca,idkategoria,tytul,cena))
    con.commit()
    return redirect(url_for("tabela6"))
def obraz_del(id):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute("DELETE FROM obraz WHERE idobraz= ?",(id,))
    con.commit()
    return redirect(url_for("tabela6"))
def obraz_update(idobraz,idtworca,idkategoria,tytul,cena):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('UPDATE obraz SET idtworca=? where idobraz=?',(idtworca,idobraz))
    cur.execute('UPDATE obraz SET idkategoria=? where idobraz=?',(idtworca,idobraz))
    cur.execute('UPDATE obraz SET tytul=? where idobraz=?',(tytul,idobraz))
    cur.execute('UPDATE obraz SET cena=? where idobraz=?',(cena,idobraz))
    con.commit()
    return redirect(url_for("tabela6"))


#ZAMOWIENIE
def zamowieniePokaz():
    cur.execute(
        """
        SELECT * FROM zamowienie
        """)
    row = cur.fetchone()
    names = row.keys()
    naglowek=[]
    for row in names:
        naglowek.append(row)
    naglowek=tuple(i for i in naglowek)
    cur.execute(
        """
        SELECT * FROM zamowienie
        """)
    osoby = cur.fetchall()
    rekordy=[]
    rekordy.append(naglowek)
    for row in osoby:
        rekordy.append(tuple(row))
    import numpy as np
    data_array7=np.array(rekordy)
    return data_array7
data_array7=zamowieniePokaz()
def zamowienie_insert(idklient,idznizka,data_zlozenia_zamowienia,data_przyjecia_zamowienia,data_wysylki,data_realizacji,platnosc):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('INSERT INTO zamowienie VALUES(NULL,?,?,?,?,?,?,?)',(idklient,idznizka,data_zlozenia_zamowienia,data_przyjecia_zamowienia,data_wysylki,data_realizacji,platnosc))
    con.commit()
    return redirect(url_for("tabela7"))
def zamowienie_del(id):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute("DELETE FROM zamowienie WHERE idzamowienie= ?",(id,))
    con.commit()
    return redirect(url_for("tabela7"))
def zamowienie_update(idzamowienie,idklient,idznizka,data_zlozenia_zamowienia,data_przyjecia_zamowienia,data_wysylki,data_realizacji,platnosc):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('UPDATE zamowienie SET idklient=? where idzamowienie=?',(idklient,idzamowienie))
    cur.execute('UPDATE zamowienie SET idznizka=? where idzamowienie=?',(idznizka,idzamowienie))
    cur.execute('UPDATE zamowienie SET data_zlozenia_zamowienia=? where idzamowienie=?',(data_zlozenia_zamowienia,idzamowienie))
    cur.execute('UPDATE zamowienie SET data_przyjecia_zamowienia=? where idzamowienie=?',(data_przyjecia_zamowienia,idzamowienie))
    cur.execute('UPDATE zamowienie SET data_wysylki=? where idzamowienie=?',(data_wysylki,idzamowienie))
    cur.execute('UPDATE zamowienie SET data_realizacji=? where idzamowienie=?',(data_realizacji,idzamowienie))
    cur.execute('UPDATE zamowienie SET platnosc=? where idzamowienie=?',(platnosc,idzamowienie))
    con.commit()
    return redirect(url_for("tabela7"))

#EGZEMPLARZ
def egzemplarzPokaz():
    cur.execute(
        """
        SELECT * FROM egzemplarz
        """)
    row = cur.fetchone()
    names = row.keys()
    naglowek=[]
    for row in names:
        naglowek.append(row)
    naglowek=tuple(i for i in naglowek)
    cur.execute(
        """
        SELECT * FROM egzemplarz
        """)
    osoby = cur.fetchall()
    rekordy=[]
    rekordy.append(naglowek)
    for row in osoby:
        rekordy.append(tuple(row))
    import numpy as np
    data_array8=np.array(rekordy)
    return data_array8
data_array8=egzemplarzPokaz()
def egzemplarz_insert(idzamowienie,idobraz,data_zakupu):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('INSERT INTO zamowienie VALUES(NULL,?,?,?)',(idzamowienie,idobraz,data_zakupu))
    con.commit()
    return redirect(url_for("tabela8"))
def egzemplarz_del(id):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute("DELETE FROM egzemplarz WHERE idegzemplarz= ?",(id,))
    con.commit()
    return redirect(url_for("tabela8"))
def egzemplarz_update(idegzemplarz,idzamowienie,idobraz,data_zakupu):
    con = sqlite3.connect("baza1.db")
    cur = con.cursor()
    cur.execute('UPDATE egzemplarz SET idzamowienie=? where idegzemplarz=?',(idzamowienie,idegzemplarz))
    cur.execute('UPDATE egzemplarz SET idobraz=? where idegzemplarz=?',(idobraz,idegzemplarz))
    cur.execute('UPDATE egzemplarz SET data_zakupu=? where idegzemplarz=?',(data_zakupu,idegzemplarz))
    con.commit()
    return redirect(url_for("tabela8"))




#WIDOKI

cur.execute(
    """
    SELECT * FROM klient_z_adresem
    """)
row = cur.fetchone()
names = row.keys()
naglowek=[]
for row in names:
    naglowek.append(row)
naglowek=tuple(i for i in naglowek)
cur.execute(
    """
    SELECT * FROM klient_z_adresem
    """)
miasta = cur.fetchall()
rekordy=[]
rekordy.append(naglowek)
for row in miasta:
    rekordy.append(tuple(row))
data_array9=np.array(rekordy)

cur.execute(
    """
    SELECT * FROM obraz_cena_powyzej_50
    """)
row = cur.fetchone()
names = row.keys()
naglowek=[]
for row in names:
    naglowek.append(row)
naglowek=tuple(i for i in naglowek)
cur.execute(
    """
    SELECT * FROM obraz_cena_powyzej_50
    """)
miasta = cur.fetchall()
rekordy=[]
rekordy.append(naglowek)
for row in miasta:
    rekordy.append(tuple(row))
data_array10=np.array(rekordy)

cur.execute(
    """
    SELECT * FROM tworcy_z_Gdyni
    """)
row = cur.fetchone()
names = row.keys()
naglowek=[]
for row in names:
    naglowek.append(row)
naglowek=tuple(i for i in naglowek)
cur.execute(
    """
    SELECT * FROM tworcy_z_Gdyni
    """)
miasta = cur.fetchall()
rekordy=[]
rekordy.append(naglowek)
for row in miasta:
    rekordy.append(tuple(row))
con.close()
data_array11=np.array(rekordy)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/tabele')
def tabele():
    return render_template('tabele.html')

@app.route('/tabele/adres', methods=['POST','GET'])
def tabela1():
    if request.method == 'POST':
        a1 = request.form.get(data_array[0][1])
        a2 = request.form.get(data_array[0][2])
        a3 = request.form.get(data_array[0][3])
        a4 = request.form.get(data_array[0][4])
        a5 = request.form.get(data_array[0][5])
        delete = request.form.get('idDel')
        update=request.form.get("Update"+data_array[0][0])
        update1= request.form.get("Update"+data_array[0][1])
        update2= request.form.get("Update"+data_array[0][2])
        update3= request.form.get("Update"+data_array[0][3])
        update4= request.form.get("Update"+data_array[0][4])
        update5= request.form.get("Update"+data_array[0][5])
        if delete !=None:
            print("Usuwam id = "+str(delete))
            return adres_del(delete)
        elif update != None:
            return adres_update(update,update1,update2,update3,update4,update5)
        else:
            return adres_insert(a1,a2,a3,a4,a5)
    else:
        return render_template('tabela1.html',dane=data_array)


@app.route('/tabele/tworca', methods=['POST','GET'])
def tabela2():
    if request.method == 'POST':
        t1 = request.form.get(data_array2[0][1])
        t2 = request.form.get(data_array2[0][2])
        t3 = request.form.get(data_array2[0][3])
        t4 = request.form.get(data_array2[0][4])
        t5 = request.form.get(data_array2[0][5])
        t6 = request.form.get(data_array2[0][6])
        delete = request.form.get('idDel')
        t_update=request.form.get("Update"+data_array2[0][0])
        t_update1= request.form.get("Update"+data_array2[0][1])
        t_update2= request.form.get("Update"+data_array2[0][2])
        t_update3= request.form.get("Update"+data_array2[0][3])
        t_update4= request.form.get("Update"+data_array2[0][4])
        t_update5= request.form.get("Update"+data_array2[0][5])
        t_update6= request.form.get("Update"+data_array2[0][6])
        if delete !=None:
            print("Usuwam id = "+str(delete))
            return tworca_del(delete)
        elif t_update != None:
            return tworca_update(t_update,t_update1,t_update2,t_update3,t_update4,t_update5,t_update6)
        else:
            return tworca_insert(t1,t2,t3,t4,t5,t6)
    else:
        return render_template('tabela2.html',dane=data_array2)


@app.route('/tabele/klient', methods=['POST','GET'])
def tabela3():
    if request.method == 'POST':
        k1 = request.form.get(data_array3[0][1])
        k2 = request.form.get(data_array3[0][2])
        k3 = request.form.get(data_array3[0][3])
        k4 = request.form.get(data_array3[0][4])
        k5 = request.form.get(data_array3[0][5])
        k6 = request.form.get(data_array3[0][6])
        delete = request.form.get('idDel')
        k_update=request.form.get("Update"+data_array3[0][0])
        k_update1= request.form.get("Update"+data_array3[0][1])
        k_update2= request.form.get("Update"+data_array3[0][2])
        k_update3= request.form.get("Update"+data_array3[0][3])
        k_update4= request.form.get("Update"+data_array3[0][4])
        k_update5= request.form.get("Update"+data_array3[0][5])
        k_update6= request.form.get("Update"+data_array3[0][6])
        if delete !=None:
            print("Usuwam id = "+str(delete))
            return klient_del(delete)
        elif k_update != None:
            return klient_update(k_update,k_update1,k_update2,k_update3,k_update4,k_update5,k_update6)
        else:
            return klient_insert(k1,k2,k3,k4,k5,k6)
    else:
        return render_template('tabela3.html',dane=data_array3)


@app.route('/tabele/znizka', methods=['POST','GET'])
def tabela4():
    if request.method == 'POST':
        z1 = request.form.get(data_array4[0][1])
        delete = request.form.get('idDel')
        z_update=request.form.get("Update"+data_array4[0][0])
        z_update1= request.form.get("Update"+data_array4[0][1])
        if delete !=None:
            print("Usuwam id = "+str(delete))
            return znizka_del(delete)
        elif z_update != None:
            return znizka_update(z_update,z_update1)
        else:
            return znizka_insert(z1)
    else:
        return render_template('tabela4.html',dane=data_array4)


@app.route('/tabele/kategoria', methods=['POST','GET'])
def tabela5():
    if request.method == 'POST':
        kat1 = request.form.get(data_array5[0][1])
        delete = request.form.get('idDel')
        kat_update=request.form.get("Update"+data_array5[0][0])
        kat_update1= request.form.get("Update"+data_array5[0][1])
        if delete !=None:
            print("Usuwam id = "+str(delete))
            return kategoria_del(delete)
        elif kat_update != None:
            return kategoria_update(kat_update,kat_update1)
        else:
            return kategoria_insert(kat1)
    else:
        return render_template('tabela5.html',dane=data_array5)


@app.route('/tabele/obraz', methods=['POST','GET'])
def tabela6():
    if request.method == 'POST':
        o1 = request.form.get(data_array6[0][1])
        o2 = request.form.get(data_array6[0][2])
        o3 = request.form.get(data_array6[0][3])
        o4 = request.form.get(data_array6[0][4])
        delete = request.form.get('idDel')
        o_update=request.form.get("Update"+data_array6[0][0])
        o_update1= request.form.get("Update"+data_array6[0][1])
        o_update2= request.form.get("Update"+data_array6[0][2])
        o_update3= request.form.get("Update"+data_array6[0][3])
        o_update4= request.form.get("Update"+data_array6[0][4])
        if delete !=None:
            print("Usuwam id = "+str(delete))
            return obraz_del(delete)
        elif o_update != None:
            return obraz_update(o_update,o_update1,o_update2,o_update3,o_update4)
        else:
            return obraz_insert(o1,o2,o3,o4)
    else:
        return render_template('tabela6.html',dane=data_array6)


@app.route('/tabele/zamowienie', methods=['POST','GET'])
def tabela7():
    if request.method == 'POST':
        zam1 = request.form.get(data_array7[0][1])
        zam2 = request.form.get(data_array7[0][2])
        zam3 = request.form.get(data_array7[0][3])
        zam4 = request.form.get(data_array7[0][4])
        zam5 = request.form.get(data_array7[0][5])
        zam6 = request.form.get(data_array7[0][6])
        zam7 = request.form.get(data_array7[0][7])
        delete = request.form.get('idDel')
        zam_update=request.form.get("Update"+data_array7[0][0])
        zam_update1= request.form.get("Update"+data_array7[0][1])
        zam_update2= request.form.get("Update"+data_array7[0][2])
        zam_update3= request.form.get("Update"+data_array7[0][3])
        zam_update4= request.form.get("Update"+data_array7[0][4])
        zam_update5= request.form.get("Update"+data_array7[0][5])
        zam_update6= request.form.get("Update"+data_array7[0][6])
        zam_update7= request.form.get("Update"+data_array7[0][7])
        if delete !=None:
            print("Usuwam id = "+str(delete))
            return zamowienie_del(delete)
        elif zam_update != None:
            return zamowienie_update(zam_update,zam_update1,zam_update2,zam_update3,zam_update4,zam_update5,zam_update6,zam_update7)
        else:
            return zamowieie_insert(zam1,zam2,zam3,zam4,zam5,zam6,zam7)
    else:
        return render_template('tabela7.html',dane=data_array7)


@app.route('/tabele/egemplarz', methods=['POST','GET'])
def tabela8():
    if request.method == 'POST':
        e1 = request.form.get(data_array8[0][1])
        e2 = request.form.get(data_array8[0][2])
        e3 = request.form.get(data_array8[0][3])
        delete = request.form.get('idDel')
        e_update=request.form.get("Update"+data_array8[0][0])
        e_update1= request.form.get("Update"+data_array8[0][1])
        e_update2= request.form.get("Update"+data_array8[0][2])
        e_update3= request.form.get("Update"+data_array8[0][3])
        if delete !=None:
            print("Usuwam id = "+str(delete))
            return egzemplarz_del(delete)
        elif e_update != None:
            return egzemplarz_update(e_update,e_update1,e_update2,e_update3)
        else:
            return egzemplarz_insert(e1,e2,e3)
    else:
        return render_template('tabela8.html',dane=data_array8)

@app.route('/widoki')
def widoki():
    return render_template('widoki.html')

@app.route('/widoki/widok1')
def widok1():
    return render_template('widok1.html',dane=data_array9)

@app.route('/widoki/widok2')
def widok2():
    return render_template('widok2.html',dane=data_array10)

@app.route('/widoki/widok3')
def widok3():
    return render_template('widok3.html',dane=data_array11)


if __name__ == '__main__':
    app.run(debug=True)     